# app/devtools/seed_helpers.py

import random
from faker import Faker
from datetime import datetime, timedelta
from app.models.client import Client
from app.models.employee import Employee
from app.models.visit import Visit
from app.models.tag import Tag
from app.models.user import User
from app.core.security import get_password_hash  # ✅ confirmed
from sqlalchemy.orm import Session

fake = Faker("en_GB")


def run_reset(db: Session):
    db.query(Visit).delete()
    db.query(Employee).delete()
    db.query(Client).delete()
    db.query(Tag).delete()
    db.query(User).filter(User.username != "ric_admin").delete()
    db.commit()


def run_seed(db: Session):
    run_reset(db)

    # Create tags
    tag_names = set()
    while len(tag_names) < 5:
        tag_names.add(fake.unique.word())

    tags = [Tag(name=name) for name in tag_names]
    db.add_all(tags)
    db.commit()

    # Create clients (use only fields that exist in model)
    clients = []
    for _ in range(10):
        client = Client(
            full_name=fake.name(),
            address=fake.address(),
            contact_method=random.choice(["phone", "email", "in-person"]),
            safeguarding_info=fake.sentence(),
            access_details=fake.sentence(),
            care_notes=fake.paragraph(),
        )
        db.add(client)
        clients.append(client)
    db.commit()

    # Create employees
    employees = []
    for _ in range(5):
        employee = Employee(
            full_name=fake.name(),
            role=random.choice(["carer", "senior"]),
            status="active",
            start_date=fake.date_this_decade(),
            availability_summary=fake.sentence(),
            has_car=random.choice([True, False]),
        )
        employee.tags = random.sample(tags, k=random.randint(0, len(tags)))
        employee.preferred_clients = random.sample(clients, k=random.randint(0, len(clients)))
        db.add(employee)
        employees.append(employee)
    db.commit()

    # Create visits (with some conflict)
    for i in range(10):
        client = random.choice(clients)
        employee = random.choice(employees)
        visit_date = datetime.today().date()

        # Some overlap
        base_time = datetime.combine(visit_date, datetime.min.time()) + timedelta(hours=8)
        start_time = base_time + timedelta(minutes=30 * (i % 3))
        end_time = start_time + timedelta(minutes=30)

        visit = Visit(
            client_id=client.id,
            employee_id=employee.id,
            start_time=start_time,
            end_time=end_time,
            notes=random.choice(["Routine check", "meds", "food prep"]),
        )
        db.add(visit)
    db.commit()

    # Dev user
    if not db.query(User).filter_by(username="ric_admin").first():
        user = User(
            username="ric_admin",
            role="admin",
            hashed_password=get_password_hash("password")
        )
        db.add(user)
        db.commit()
